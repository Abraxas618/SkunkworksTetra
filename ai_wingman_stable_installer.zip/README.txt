AI Wingman Installation Guide:
1. Run setup.bat (Windows) or setup.sh (Mac/Linux)
2. Launch AI_Wingman.exe
3. Start Project Wingman and let AI assist you.